// assets/charts.js
(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var accent4 = style.getPropertyValue('--accent4').trim();
  var accent5 = style.getPropertyValue('--accent5').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var aiplA = style.getPropertyValue('--aipl-a').trim();
  var aiplI = style.getPropertyValue('--aipl-i').trim();
  var aiplP = style.getPropertyValue('--aipl-p').trim();
  var aiplL = style.getPropertyValue('--aipl-l').trim();

  // ===== Chart 1: Funnel Overview =====
  (function() {
    var el = document.getElementById('chart-funnel-overview');
    if (!el) return;
    var chart = echarts.init(el, null, { renderer: 'svg' });

    var funnelNames = ['种草漏斗', '体验漏斗', '激活漏斗', '留存推荐漏斗', '数据反哺漏斗'];
    var funnelValues = [100, 38, 62, 48, 72];
    var funnelColors = [aiplA, aiplI, aiplP, aiplL, accent4];

    chart.setOption({
      animation: false,
      tooltip: {
        trigger: 'item',
        appendToBody: true,
        formatter: function(p) {
          return p.name + '<br/>健康度: <b>' + p.value + '%</b>';
        }
      },
      series: [{
        type: 'funnel',
        left: '10%',
        top: 20,
        bottom: 20,
        width: '80%',
        min: 0,
        max: 100,
        sort: 'descending',
        gap: 2,
        label: {
          show: true,
          position: 'inside',
          formatter: '{b}',
          fontSize: 13,
          color: '#fff',
          fontWeight: 700
        },
        labelLine: {
          length: 10,
          lineStyle: { width: 1, color: muted }
        },
        itemStyle: {
          borderColor: '#fff',
          borderWidth: 0
        },
        emphasis: {
          label: { fontSize: 16 }
        },
        data: [
          { value: funnelValues[0], name: funnelNames[0], itemStyle: { color: funnelColors[0] } },
          { value: funnelValues[1], name: funnelNames[1], itemStyle: { color: funnelColors[1] } },
          { value: funnelValues[2], name: funnelNames[2], itemStyle: { color: funnelColors[2] } },
          { value: funnelValues[3], name: funnelNames[3], itemStyle: { color: funnelColors[3] } },
          { value: funnelValues[4], name: funnelNames[4], itemStyle: { color: funnelColors[4] } }
        ]
      }]
    });

    window.addEventListener('resize', function() { chart.resize(); });
  })();

  // ===== Chart 2: Radar - Funnel Health =====
  (function() {
    var el = document.getElementById('chart-radar');
    if (!el) return;
    var chart = echarts.init(el, null, { renderer: 'svg' });

    chart.setOption({
      animation: false,
      tooltip: {
        trigger: 'item',
        appendToBody: true
      },
      legend: {
        bottom: 0,
        textStyle: { color: muted, fontSize: 12 }
      },
      radar: {
        center: ['50%', '50%'],
        radius: '65%',
        indicator: [
          { name: '埋点覆盖', max: 100 },
          { name: '标签准确', max: 100 },
          { name: '激活转化', max: 100 },
          { name: '推荐率', max: 100 },
          { name: 'NPS', max: 100 },
          { name: '数据迭代', max: 100 }
        ],
        axisName: { color: muted, fontSize: 11 },
        splitArea: { areaStyle: { color: ['rgba(59,130,246,0.02)', 'rgba(59,130,246,0.02)'] } },
        splitLine: { lineStyle: { color: rule } },
        axisLine: { lineStyle: { color: rule } }
      },
      series: [{
        type: 'radar',
        data: [{
          value: [92, 78, 65, 48, 55, 70],
          name: '当前状态',
          lineStyle: { color: accent, width: 2 },
          areaStyle: { color: accent + '33' },
          itemStyle: { color: accent },
          symbol: 'circle',
          symbolSize: 6
        }, {
          value: [95, 90, 85, 75, 75, 88],
          name: '目标基线',
          lineStyle: { color: accent3, width: 2, type: 'dashed' },
          areaStyle: { color: 'transparent' },
          itemStyle: { color: accent3 },
          symbol: 'diamond',
          symbolSize: 6
        }]
      }]
    });

    window.addEventListener('resize', function() { chart.resize(); });
  })();

  // ===== Chart 3: Loss Distribution by Funnel =====
  (function() {
    var el = document.getElementById('chart-loss');
    if (!el) return;
    var chart = echarts.init(el, null, { renderer: 'svg' });

    chart.setOption({
      animation: false,
      tooltip: {
        trigger: 'axis',
        appendToBody: true,
        axisPointer: { type: 'shadow' }
      },
      grid: {
        left: 50,
        right: 30,
        top: 20,
        bottom: 60
      },
      xAxis: {
        type: 'category',
        data: ['曝光→种草', '种草→意向', '浅层→深度', '深度→下单', '到货→开箱', '配网→激活', '活跃→满意', '满意→推荐', '洞察→硬件'],
        axisLabel: {
          color: muted,
          fontSize: 10,
          rotate: 35,
          interval: 0
        },
        axisTick: { alignWithLabel: true },
        axisLine: { lineStyle: { color: rule } }
      },
      yAxis: {
        type: 'value',
        name: '流失率 %',
        nameTextStyle: { color: muted, fontSize: 11 },
        axisLabel: { color: muted, fontSize: 11 },
        splitLine: { lineStyle: { color: rule } },
        max: 50
      },
      series: [{
        type: 'bar',
        barWidth: '55%',
        data: [
          { value: 32, itemStyle: { color: aiplA } },
          { value: 22, itemStyle: { color: aiplA + 'cc' } },
          { value: 28, itemStyle: { color: aiplI } },
          { value: 18, itemStyle: { color: aiplI + 'cc' } },
          { value: 8, itemStyle: { color: aiplP } },
          { value: 15, itemStyle: { color: accent5 } },
          { value: 25, itemStyle: { color: aiplL } },
          { value: 20, itemStyle: { color: accent3 } },
          { value: 35, itemStyle: { color: accent4 } }
        ],
        label: {
          show: true,
          position: 'top',
          formatter: '{c}%',
          color: muted,
          fontSize: 11,
          fontWeight: 600
        },
        itemStyle: {
          borderRadius: [4, 4, 0, 0]
        }
      }]
    });

    window.addEventListener('resize', function() { chart.resize(); });
  })();
})();